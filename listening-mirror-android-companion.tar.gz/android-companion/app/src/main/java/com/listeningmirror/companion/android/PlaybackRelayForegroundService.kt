package com.listeningmirror.companion.android

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/**
 * Keeps the process at foreground importance for as long as Notification
 * Access is active, so MediaSession observation and the existing 20s relay
 * heartbeat are not suspended when the companion UI is backgrounded or the
 * screen is locked.
 *
 * Real-device evidence this exists to fix: with YouTube genuinely playing
 * and the relay state correct (isPlaying: true), Supabase received_at aged
 * to 39s against a 20s heartbeat, and the web correctly expired the state
 * after 60s. The web TTL and arbitration behaved properly; the Android
 * process was being suspended.
 *
 * LIFECYCLE IS TIED TO THE LISTENER CONNECTION, NEVER TO PLAYBACK STATE.
 * A paused track, a momentarily-null selected session, or a MediaSession
 * transition must not stop this service -- tying it to isPlaying would
 * recreate, on the Android side, exactly the class of disappear-on-pause
 * bug that mirror.js's MAX_TOLERATED_MISSES was written to fix on the web
 * side. It runs while the listener is connected and stops when it isn't.
 *
 * Deliberately owns NOTHING else: no normalization, no session selection,
 * no relay protocol. MediaNotificationListenerService remains the owner of
 * AndroidMediaSessionProvider and RelayPublisher.
 */
class PlaybackRelayForegroundService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopCleanly()
            return START_NOT_STICKY
        }

        // A null intent means the system restarted us after killing the
        // process (START_STICKY). Only stay up if observation genuinely got
        // re-established; otherwise we'd show a "detection active"
        // notification over nothing actually running.
        if (intent == null && RelayPublisherHolder.get() == null) {
            stopCleanly()
            return START_NOT_STICKY
        }

        // Promptly, on every start command: Android requires startForeground
        // within a few seconds of startForegroundService(), and calling it
        // again on an already-foreground service is a harmless no-op that
        // just refreshes the notification -- which is what makes repeated
        // listener reconnects idempotent rather than duplicating anything.
        startForegroundCompat()
        return START_STICKY
    }

    private fun startForegroundCompat() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun stopCleanly() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        stopSelf()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java) ?: return
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Playback detection",
            // LOW: the notification is a platform requirement for a
            // foreground service, not something worth interrupting for.
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Shown while Listening Mirror is observing media playback."
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        return builder
            .setContentTitle("Listening Mirror · playback detection active")
            .setContentText("Observing media sessions while Notification Access is on.")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val CHANNEL_ID = "lm_playback_relay"
        private const val NOTIFICATION_ID = 4711
        private const val ACTION_STOP = "com.listeningmirror.companion.STOP_KEEPALIVE"

        /**
         * Idempotent. Safe to call on every listener reconnect: Android
         * routes a second startForegroundService() to the SAME service
         * instance's onStartCommand, so this can never produce a duplicate
         * service or a duplicate notification.
         *
         * Returns false when the platform refused the start.
         */
        fun ensureRunning(context: Context): Boolean {
            val intent = Intent(context, PlaybackRelayForegroundService::class.java)
            return try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
                true
            } catch (e: Exception) {
                // Android 12+ can refuse a foreground-service start made from
                // the background (ForegroundServiceStartNotAllowedException).
                // onListenerConnected can legitimately fire while the app has
                // no visible UI -- at boot, or on a system rebind -- so this
                // is an expected outcome, not a crash case. DebugActivity
                // retries from a guaranteed-foreground context on resume.
                false
            }
        }

        /** Idempotent: stopping an already-stopped service is a no-op. */
        fun stop(context: Context) {
            val intent = Intent(context, PlaybackRelayForegroundService::class.java)
                .setAction(ACTION_STOP)
            try {
                context.startService(intent)
            } catch (e: Exception) {
                // Nothing running to stop, or the platform refused -- either
                // way there is nothing left to clean up here.
            }
        }
    }
}
