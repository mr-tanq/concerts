package com.listeningmirror.companion.android

import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.listeningmirror.companion.ambient.AmbientConfig
import com.listeningmirror.companion.ambient.AmbientTokenStore

class AmbientSettingsActivity : AppCompatActivity() {
    private lateinit var store: AmbientTokenStore
    private lateinit var input: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = AmbientTokenStore(this)
        val root = ScrollView(this)
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 48)
        }
        root.addView(column)

        column.addView(TextView(this).apply {
            text = "AMBIENT · AudD API"
            typeface = android.graphics.Typeface.MONOSPACE
            textSize = 13f
            setPadding(0, 0, 0, 20)
        })
        column.addView(TextView(this).apply {
            text = "A real AudD API token enables smart continuous recognition. " +
                "Without one, Listening Mirror uses AudD's public 'test' token " +
                "and performs one recognition per START (public limit: 10/day).\n\n" +
                "Your token is encrypted with Android Keystore and is never sent to the Listening Mirror relay."
            textSize = 12f
            setPadding(0, 0, 0, 20)
        })

        input = EditText(this).apply {
            hint = "AudD API token"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        column.addView(input)
        column.addView(Button(this).apply {
            text = "Save AudD token"
            setOnClickListener {
                val value = input.text.toString().trim()
                if (value.isBlank()) {
                    refresh("Nothing pasted.")
                } else {
                    store.save(value)
                    input.setText("")
                    refresh("AudD token saved.")
                }
            }
        })
        column.addView(Button(this).apply {
            text = "Use public test token"
            setOnClickListener {
                store.clear()
                input.setText("")
                refresh("Saved token cleared.")
            }
        })
        status = TextView(this).apply {
            typeface = android.graphics.Typeface.MONOSPACE
            textSize = 12f
            setPadding(0, 28, 0, 0)
        }
        column.addView(status)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh(null)
    }

    private fun refresh(message: String?) {
        status.text = buildString {
            if (message != null) append(message).append("\n\n")
            if (store.hasToken()) {
                append("Token: configured\nMode: smart continuous")
            } else {
                append("Token: public '").append(AmbientConfig.PUBLIC_TEST_TOKEN).append("'\n")
                append("Mode: single recognition per START · max 10 requests/day")
            }
        }
    }
}
