package com.listeningmirror.companion.ambient

object AmbientConfig {
    const val SOURCE = "ambient_audd"
    const val PUBLIC_TEST_TOKEN = "test"
    const val SAMPLE_RATE_HZ = 44_100
    const val SAMPLE_DURATION_MS = 8_000L

    // Local signal gate: never spend a recognition request on near-silence.
    const val MIN_RMS_DBFS = -55.0
    const val MIN_PEAK_DBFS = -42.0

    // Retry policy for a REAL token. Public test token is deliberately
    // single-shot because AudD caps it at 10 requests/day.
    const val NO_MATCH_RETRY_MS = 12_000L
    const val UNKNOWN_DURATION_RETRY_MS = 45_000L
    const val MIN_MATCH_RETRY_MS = 20_000L
    const val MAX_MATCH_RETRY_MS = 180_000L
    const val BEFORE_EXPECTED_END_MS = 4_000L
    const val DEVICE_PLAYBACK_RECHECK_MS = 5_000L
}
