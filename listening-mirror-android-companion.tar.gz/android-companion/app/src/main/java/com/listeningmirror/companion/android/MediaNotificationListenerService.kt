package com.listeningmirror.companion.android

import android.service.notification.NotificationListenerService
import com.listeningmirror.companion.transport.RelayPublisher

/**
 * Two jobs, both structural, neither involving notification content:
 *
 *  1. Being an *enabled* NotificationListenerService is what unlocks
 *     MediaSessionManager.getActiveSessions() for a normal app (the
 *     alternative, MEDIA_CONTENT_CONTROL, is system-level).
 *
 *  2. It is the LIFECYCLE HOST for MediaSession observation. This matters
 *     more than it looks: the whole point of the companion is to observe
 *     Spotify/YouTube *while the user is in Spotify/YouTube*, which is
 *     exactly when our own Activity is backgrounded. Hosting the observer
 *     in the Activity would tear the callbacks down at the precise moment
 *     they need to be live, so the test sequence would only ever capture
 *     fresh snapshots on return -- proving nothing about continuous
 *     observation. The system binds this service and keeps it bound
 *     independently of any Activity, which is the property we need.
 *
 * It deliberately does NOT override onNotificationPosted /
 * onNotificationRemoved, and never reads notification content, text, or
 * extras. Using it as a lifecycle/permission host does not change that
 * rule. If this class ever grows notification-parsing logic, something has
 * gone off-plan.
 */
class MediaNotificationListenerService : NotificationListenerService() {

    private var provider: AndroidMediaSessionProvider? = null
    private var publisher: RelayPublisher? = null

    /**
     * The platform's documented signal that the listener is genuinely
     * connected and its APIs are usable -- the AOSP docs explicitly say to
     * wait for this before performing operations. Starting observation
     * from onCreate() instead would race the binding.
     */
    override fun onListenerConnected() {
        super.onListenerConnected()

        // Android can call onListenerConnected more than once for the same
        // logical connection (system rebinds, access toggled off and on).
        // Tearing down first makes reconnect idempotent -- without it, a
        // second provider and publisher would run in parallel, each with
        // their own heartbeat and sequence counter.
        teardown()

        // Foreground keepalive FIRST, so the process is already at
        // foreground importance before observation starts. Tied to the
        // listener connection, never to playback state.
        PlaybackRelayForegroundService.ensureRunning(applicationContext)

        val p = AndroidMediaSessionProvider(applicationContext)
        provider = p
        val pub = RelayPublisher(applicationContext)
        publisher = pub
        RelayPublisherHolder.set(pub)
        ObservationHub.attachProvider(p)
        pub.start()
        // Minimal two-call fan-out. ObservationHub deliberately stays a
        // single-subscriber debug seam rather than being refactored into a
        // general event bus just to add transport.
        p.start { snapshot ->
            ObservationHub.publish(snapshot)
            pub.onSnapshot(snapshot)
        }
    }

    override fun onListenerDisconnected() {
        // Notification Access was revoked, or the system is unbinding us.
        // Either way this is a genuine end of the continuous observation
        // session -- tear down fully, including selection stickiness.
        teardown()
        super.onListenerDisconnected()
    }

    /**
     * Idempotent, and safe to call in any order relative to the platform's
     * own lifecycle callbacks -- Android does not guarantee
     * onListenerDisconnected precedes onDestroy, or that either fires only
     * once, so every step here tolerates already having been done.
     */
    private fun teardown() {
        provider?.stop()
        provider = null
        publisher?.stop()
        publisher = null
        RelayPublisherHolder.set(null)
        ObservationHub.detachProvider()
        PlaybackRelayForegroundService.stop(applicationContext)
    }

    override fun onDestroy() {
        teardown()
        super.onDestroy()
    }
}
