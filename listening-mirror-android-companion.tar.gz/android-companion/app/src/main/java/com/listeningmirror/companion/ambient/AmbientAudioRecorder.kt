package com.listeningmirror.companion.ambient

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import java.io.ByteArrayOutputStream

class AmbientAudioRecorder {
    @Volatile private var active: AudioRecord? = null

    fun captureWav(durationMs: Long = AmbientConfig.SAMPLE_DURATION_MS): ByteArray {
        val minBuffer = AudioRecord.getMinBufferSize(
            AmbientConfig.SAMPLE_RATE_HZ,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
        )
        require(minBuffer > 0) { "AudioRecord buffer unavailable: $minBuffer" }
        val bufferSize = maxOf(minBuffer, 4096)
        val recorder = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            AmbientConfig.SAMPLE_RATE_HZ,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSize * 2,
        )
        if (recorder.state != AudioRecord.STATE_INITIALIZED) {
            recorder.release()
            error("AudioRecord failed to initialize")
        }

        active = recorder
        val bytesNeeded = ((AmbientConfig.SAMPLE_RATE_HZ * 2L * durationMs) / 1000L).toInt()
        val pcm = ByteArrayOutputStream(bytesNeeded)
        val buf = ByteArray(bufferSize)
        try {
            recorder.startRecording()
            while (pcm.size() < bytesNeeded && !Thread.currentThread().isInterrupted) {
                val want = minOf(buf.size, bytesNeeded - pcm.size())
                val n = recorder.read(buf, 0, want, AudioRecord.READ_BLOCKING)
                if (n > 0) pcm.write(buf, 0, n)
                else if (n < 0) error("AudioRecord read failed: $n")
            }
        } finally {
            runCatching { if (recorder.recordingState == AudioRecord.RECORDSTATE_RECORDING) recorder.stop() }
            recorder.release()
            active = null
        }
        if (pcm.size() < bytesNeeded / 2) error("Audio capture ended too early")
        return PcmWav.encode16BitMono(pcm.toByteArray(), AmbientConfig.SAMPLE_RATE_HZ)
    }

    fun cancel() {
        val r = active ?: return
        runCatching { r.stop() }
    }
}
