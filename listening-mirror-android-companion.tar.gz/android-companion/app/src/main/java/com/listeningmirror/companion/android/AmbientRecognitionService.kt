package com.listeningmirror.companion.android

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import com.listeningmirror.companion.ambient.AmbientAudioRecorder
import com.listeningmirror.companion.ambient.AmbientConfig
import com.listeningmirror.companion.ambient.AmbientRecognitionResult
import com.listeningmirror.companion.ambient.AmbientStatus
import com.listeningmirror.companion.ambient.AmbientTokenStore
import com.listeningmirror.companion.ambient.AudDRecognitionClient
import com.listeningmirror.companion.model.CurrentListeningState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * User-started microphone foreground service for external/ambient music.
 * It never starts from the background: DebugActivity owns the permission and
 * visible-context start path required by Android 14/15.
 */
class AmbientRecognitionService : Service() {
    @Volatile private var alive = false
    private var worker: Thread? = null
    private val recorder = AmbientAudioRecorder()

    private val isoFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            AmbientStatus.update(running = false, phase = "MICROPHONE PERMISSION MISSING", lastError = "RECORD_AUDIO not granted")
            stopSelf()
            return START_NOT_STICKY
        }
        startForegroundCompat()
        alive = true

        // Repeated starts while the service is already up are idempotent.
        if (worker?.isAlive != true) {
            val storedToken = AmbientTokenStore(this).load()
            val token = storedToken ?: AmbientConfig.PUBLIC_TEST_TOKEN
            val usingTest = storedToken == null
            AmbientStatus.update(
                running = true,
                phase = if (usingTest) "READY · public test token · single shot" else "READY · smart continuous",
                usingTestToken = usingTest,
                requestCount = 0,
                lastMatch = null,
                lastError = null,
            )
            worker = Thread({ recognitionLoop(token, usingTest) }, "ambient-recognition").apply { start() }
        }
        return START_NOT_STICKY
    }

    private fun recognitionLoop(token: String, usingTestToken: Boolean) {
        val client = AudDRecognitionClient()
        while (alive && !Thread.currentThread().isInterrupted) {
            val publisher = RelayPublisherHolder.get()
            if (publisher == null || !publisher.status().hasSecret) {
                AmbientStatus.update(
                    running = true,
                    phase = "WAITING · relay secret/publisher not ready",
                    usingTestToken = usingTestToken,
                )
                if (!sleep(AmbientConfig.DEVICE_PLAYBACK_RECHECK_MS)) break
                continue
            }

            // Don't waste a recognition request fingerprinting audio that
            // Android already exposes canonically through a playing session.
            if (ObservationHub.hasPlayingDeviceMedia()) {
                RelayPublisherHolder.get()?.onAmbientState(null)
                AmbientStatus.update(
                    running = true,
                    phase = "WAITING · active device playback has priority",
                    usingTestToken = usingTestToken,
                )
                if (!sleep(AmbientConfig.DEVICE_PLAYBACK_RECHECK_MS)) break
                continue
            }

            try {
                AmbientStatus.update(running = true, phase = "LISTENING · 8 second sample", usingTestToken = usingTestToken, lastError = null)
                val wav = recorder.captureWav()
                if (!alive) break
                val nextCount = AmbientStatus.current().requestCount + 1
                AmbientStatus.update(running = true, phase = "RECOGNIZING · AudD", usingTestToken = usingTestToken, requestCount = nextCount)
                val result = client.recognize(wav, token)
                if (!alive) break

                if (result == null) {
                    RelayPublisherHolder.get()?.onAmbientState(null)
                    AmbientStatus.update(
                        running = true,
                        phase = if (usingTestToken) "NO MATCH · test shot complete" else "NO MATCH · retrying soon",
                        usingTestToken = usingTestToken,
                        lastMatch = null,
                        lastError = null,
                    )
                    if (usingTestToken) return
                    if (!sleep(AmbientConfig.NO_MATCH_RETRY_MS)) break
                } else {
                    val state = result.toState()
                    RelayPublisherHolder.get()?.onAmbientState(state)
                    AmbientStatus.update(
                        running = true,
                        phase = if (usingTestToken) "MATCH · test shot complete" else "MATCH · waiting near expected track end",
                        usingTestToken = usingTestToken,
                        lastMatch = "${result.artist} — ${result.title}",
                        lastError = null,
                    )
                    if (usingTestToken) return
                    if (!sleep(nextRecognitionDelay(result))) break
                }
            } catch (e: InterruptedException) {
                Thread.currentThread().interrupt()
                break
            } catch (e: Exception) {
                if (!alive) break
                RelayPublisherHolder.get()?.onAmbientState(null)
                AmbientStatus.update(
                    running = true,
                    phase = "ERROR · recognition paused",
                    usingTestToken = usingTestToken,
                    lastError = (e.message ?: e.javaClass.simpleName).take(220),
                )
                // Fail closed: don't spin/bill repeatedly on a bad token or a
                // persistent API problem. User can Stop/Start after fixing it.
                return
            }
        }
    }

    private fun AmbientRecognitionResult.toState(): CurrentListeningState {
        return CurrentListeningState(
            source = AmbientConfig.SOURCE,
            artist = artist,
            primaryArtist = artist,
            track = title,
            album = album,
            artwork = artworkUrl,
            isPlaying = true,
            durationMs = durationMs,
            positionMs = positionMs,
            externalId = externalId,
            externalUrl = externalUrl,
            confidence = null,
            capturedAt = isoFormat.format(Date()),
            controlsSupported = false,
        )
    }

    private fun nextRecognitionDelay(result: AmbientRecognitionResult): Long {
        val duration = result.durationMs
        val position = result.positionMs
        if (duration == null || position == null || duration <= position) {
            return AmbientConfig.UNKNOWN_DURATION_RETRY_MS
        }
        val remaining = duration - position
        return (remaining - AmbientConfig.BEFORE_EXPECTED_END_MS)
            .coerceIn(AmbientConfig.MIN_MATCH_RETRY_MS, AmbientConfig.MAX_MATCH_RETRY_MS)
    }

    private fun sleep(ms: Long): Boolean = try {
        Thread.sleep(ms)
        alive
    } catch (_: InterruptedException) {
        Thread.currentThread().interrupt()
        false
    }

    override fun onDestroy() {
        alive = false
        recorder.cancel()
        worker?.interrupt()
        worker = null
        RelayPublisherHolder.get()?.onAmbientState(null)
        AmbientStatus.update(running = false, phase = "OFF")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE)
        else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        super.onDestroy()
    }

    private fun startForegroundCompat() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIFICATION_ID, n)
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java) ?: return
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Ambient music recognition", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Shown while Listening Mirror can sample the microphone to identify external music."
                setShowBadge(false)
            }
        )
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, CHANNEL_ID)
        else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        return builder
            .setContentTitle("Listening Mirror · ambient recognition")
            .setContentText("Listening for music playing around this phone.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val CHANNEL_ID = "lm_ambient_recognition"
        private const val NOTIFICATION_ID = 4712

        /** Must be called from a visible Activity after RECORD_AUDIO grant. */
        fun startFromVisibleActivity(context: Context): Boolean {
            val intent = Intent(context, AmbientRecognitionService::class.java)
            return try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
                else context.startService(intent)
                true
            } catch (e: Exception) {
                AmbientStatus.update(running = false, phase = "START REFUSED", lastError = e.javaClass.simpleName + ": " + (e.message ?: ""))
                false
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, AmbientRecognitionService::class.java))
        }
    }
}
