# Third-party notices

## SongRec-compatible Shazam fingerprinting

Phase 3 contains a Kotlin implementation of the Shazam audio fingerprint format and
recognition flow based on the public reverse-engineering work in SongRec and the Android
implementation in Audile.

- SongRec: https://github.com/marin-m/SongRec
- Audile: https://github.com/AudileTeam/Audile
- License: GNU GPL v3 or later

The Android Companion source is distributed together with this archive under GPL-3.0-or-later.
The Shazam web endpoint used by Phase 3 is unofficial/undocumented and is not an Apple SDK.
No Apple Developer credential or paid recognition API key is required by this path.
