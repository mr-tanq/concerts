import java.io.File

/**
 * Static assertions over the real AndroidManifest.xml and sources.
 *
 * These exist because the foreground-service contract is enforced by the
 * PLATFORM at install/runtime, not by the Kotlin compiler -- a missing
 * permission or a wrong foregroundServiceType produces a crash on a real
 * Samsung, not a build error. Cheap text assertions catch that in CI.
 *
 * Deliberately NOT pretending to unit-test Android's background scheduling:
 * whether Samsung actually keeps the process alive is a real-device
 * question, and no fake test here would answer it.
 */
object ManifestChecks {

    private fun locate(relative: String): File? =
        listOf(relative, "../$relative", "app/$relative")
            .map(::File).firstOrNull { it.exists() }

    fun run(check: (String, Boolean) -> Unit) {
        val manifestFile = locate("src/main/AndroidManifest.xml")
            ?: locate("app/src/main/AndroidManifest.xml")
        if (manifestFile == null) {
            check("manifest checks: AndroidManifest.xml found", false)
            return
        }
        val raw = manifestFile.readText()
        // Strip XML comments before asserting absence: this file deliberately
        // DOCUMENTS what it does not use ("specialUse rather than dataSync",
        // "no microphone"), and a naive contains() would read those
        // explanations as violations of the very rules they describe.
        val m = raw.replace(Regex("<!--.*?-->", RegexOption.DOT_MATCHES_ALL), "")

        check("manifest: FOREGROUND_SERVICE permission declared",
            m.contains("android.permission.FOREGROUND_SERVICE\""))
        check("manifest: FOREGROUND_SERVICE_SPECIAL_USE permission declared",
            m.contains("android.permission.FOREGROUND_SERVICE_SPECIAL_USE"))
        check("manifest: PlaybackRelayForegroundService is declared",
            m.contains(".android.PlaybackRelayForegroundService"))
        check("manifest: foregroundServiceType is specialUse",
            m.contains("android:foregroundServiceType=\"specialUse\""))
        check("manifest: dataSync type is NOT used (avoids Android 15 FGS time limits)",
            !m.contains("dataSync"))
        check("manifest: PROPERTY_SPECIAL_USE_FGS_SUBTYPE present",
            m.contains("android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE"))
        check("manifest: special-use subtype has a real description",
            m.contains("Continuous local MediaSession observation"))
        check("manifest: no stale claim that the app has no internet",
            !raw.contains("NO internet"))
        check("manifest: NO microphone permission",
            !m.contains("RECORD_AUDIO") && !m.contains("CAPTURE_AUDIO"))
        check("manifest: INTERNET still declared (relay transport intact)",
            m.contains("android.permission.INTERNET"))

        // Both services must be unexported; only the launcher Activity is exported.
        val fgBlock = m.substringAfter(".android.PlaybackRelayForegroundService", "")
            .substringBefore("</service>", "")
        check("manifest: foreground service is NOT exported",
            fgBlock.contains("android:exported=\"false\""))
        val listenerBlock = m.substringAfter(".android.MediaNotificationListenerService", "")
            .substringBefore("</service>", "")
        check("manifest: notification listener is still NOT exported",
            listenerBlock.contains("android:exported=\"false\""))

        // --- source-level architecture assertions ---
        val listener = locate("src/main/java/com/listeningmirror/companion/android/MediaNotificationListenerService.kt")
            ?: locate("app/src/main/java/com/listeningmirror/companion/android/MediaNotificationListenerService.kt")
        if (listener != null) {
            val s = listener.readText()
            check("listener: starts the foreground keepalive on connect",
                s.contains("PlaybackRelayForegroundService.ensureRunning"))
            check("listener: stops the foreground keepalive on teardown",
                s.contains("PlaybackRelayForegroundService.stop"))
            check("listener: still constructs exactly ONE provider and ONE publisher",
                Regex("AndroidMediaSessionProvider\\(").findAll(s).count() == 1 &&
                Regex("RelayPublisher\\(").findAll(s).count() == 1)
            check("listener: keepalive is NOT gated on playback state",
                !s.contains("isPlaying"))
        } else {
            check("listener source located", false)
        }

        val config = locate("src/main/java/com/listeningmirror/companion/transport/RelayConfig.kt")
            ?: locate("app/src/main/java/com/listeningmirror/companion/transport/RelayConfig.kt")
        if (config != null) {
            check("transport: 20s heartbeat unchanged",
                config.readText().contains("HEARTBEAT_MS = 20_000L"))
        } else {
            check("RelayConfig source located", false)
        }

        val fg = locate("src/main/java/com/listeningmirror/companion/android/PlaybackRelayForegroundService.kt")
            ?: locate("app/src/main/java/com/listeningmirror/companion/android/PlaybackRelayForegroundService.kt")
        if (fg != null) {
            val s = fg.readText()
            check("foreground service: uses STOP_FOREGROUND_REMOVE on clean stop",
                s.contains("STOP_FOREGROUND_REMOVE"))
            check("foreground service: calls stopSelf on clean stop", s.contains("stopSelf()"))
            check("foreground service: uses a LOW importance channel",
                s.contains("IMPORTANCE_LOW"))
            check("foreground service: declares the specialUse type at startForeground",
                s.contains("FOREGROUND_SERVICE_TYPE_SPECIAL_USE"))
            check("foreground service: lifecycle is NOT gated on playback state",
                !s.contains("state.isPlaying"))
        } else {
            check("foreground service source located", false)
        }
    }
}
