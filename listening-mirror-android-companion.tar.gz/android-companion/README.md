# Listening Mirror — Android companion (Phase 1C.1: metadata + startup)

Android device-playback detection, plus transport of the normalized
CurrentListeningState to the web app via a Supabase relay.

Still NO ShazamKit, no microphone, no ambient recognition, no playback
controls, no artwork bitmap upload, and no changes to mirror.js (the web
Android provider is proven on a separate debug page; Spotify-vs-Android
arbitration is Phase 1C).

## What this does

Reads what's currently playing on the phone via Android's MediaSession
APIs (Spotify, YouTube, YouTube Music, or any other well-behaved media
app), normalizes it into the same generic `CurrentListeningState` shape
the web Mirror already understands, and displays every raw + normalized
field on one live debug screen.

## Structure

```
app/src/main/java/com/listeningmirror/companion/
  model/
    RawSessionSnapshot.kt      pure snapshot of one MediaController
    CurrentListeningState.kt   the generic contract (Android side)
  logic/                       ALL pure, unit-testable, zero android.* imports
    SourceMapper.kt            package name -> source string
    PositionNormalizer.kt      sentinel/timestamp handling
    DurationNormalizer.kt      negative-means-unknown handling
    MetadataCompleteness.kt    metadataCompleteForLyrics
    ActiveSessionSelector.kt   which session is actually active
    StateNormalizer.kt         snapshot -> CurrentListeningState
  android/                     the only files that touch android.*
    MediaNotificationListenerService.kt   permission gate only
    AndroidMediaSessionProvider.kt        event-driven MediaSession bridge
    DebugActivity.kt                      the debug screen
app/src/test/java/.../LogicTests.kt       kotlin.test unit tests
tools/VerifyRunner.kt                     standalone runner (see below)
```

## Build

```
./gradlew :app:assembleDebug
```
APK lands at `app/build/outputs/apk/debug/app-debug.apk`.

The Gradle wrapper IS included (gradlew, gradlew.bat, gradle/wrapper/),
so this command works as written -- but it still requires an Android SDK
(compileSdk 35) plus network access to Google's Maven repo on first run,
neither of which the wrapper can provide. Easiest path: open the project
in Android Studio and let it sync.

## Run the unit tests

```
./gradlew :app:testDebugUnitTest
```

`tools/VerifyRunner.kt` is a standalone duplicate of the same assertions
that runs without Gradle/JUnit/Android SDK — useful for verifying the pure
logic anywhere a JVM + kotlinc exist:

```
kotlinc app/src/main/java/com/listeningmirror/companion/model/*.kt \
        app/src/main/java/com/listeningmirror/companion/logic/*.kt \
        tools/VerifyRunner.kt -include-runtime -d verify.jar
java -jar verify.jar
```

## Lifecycle (important)

MediaSession observation is owned by MediaNotificationListenerService,
NOT by the debug Activity. Leaving the Activity to go use Spotify or
YouTube unsubscribes only the UI -- observation keeps running, which is
the entire point. ObservationHub is the seam between the two.

## Notification Access

Android only exposes media sessions to apps with Notification Access. The
app shows whether it's granted and provides a button to open the system
settings page. Granted once, persists.

Declared permissions are deliberately narrow: INTERNET for relay transport,
FOREGROUND_SERVICE + FOREGROUND_SERVICE_SPECIAL_USE for the playback keepalive,
and POST_NOTIFICATIONS so Android 13+ can show that keepalive in the normal
notification shade. Notification permission denial does not block relay
operation. No microphone. No location.

## Relay transport (Phase 1B-2)

`transport/` publishes the selected session's normalized state to
`public.publish_playback` on Supabase:

- immediate publish on meaningful change, coalesced by a 750ms debounce
- 20s heartbeat while a session is selected, with the position re-anchored
  to the heartbeat instant via SystemClock.elapsedRealtime()
- per-install deviceId + monotonic sequence under noBackupFilesDir, so a
  reinstall starts a fresh identity rather than restoring a stale one
- write secret encrypted with an Android Keystore AES/GCM key
- artwork transported only when http(s); content:// and bitmaps become null

Setup: open the app, tap "Relay transport settings", paste the write secret
once. Project URL and anon key are public config compiled into RelayConfig.

Canonical backend SQL: `supabase/phase1b2_transport.sql`.

## Background reliability (Phase 1C)

`PlaybackRelayForegroundService` keeps the process at foreground importance
so observation and the 20s heartbeat survive backgrounding and screen-off.
Added because a real Samsung S23 suspended the process: with YouTube
genuinely playing, Supabase `received_at` aged to 39s against a 20s
heartbeat, and the web correctly expired the state after 60s.

Its lifecycle follows the **NotificationListenerService connection**, never
playback state — a paused track or a momentarily-null session must not stop
it. `specialUse` foreground service type (not `dataSync`, which carries
Android 15 runtime time limits). A persistent low-importance notification is
a platform requirement for any foreground service.


## YouTube metadata confidence (Phase 1C.1)

`METADATA_KEY_ARTIST` on ordinary YouTube is often the UPLOADER, not the
musical artist (observed: `Rock & Roll Hall of Fame`). `YouTubeMetadataResolver`
therefore promotes it to canonical only on explicit evidence:

1. `<Artist> - Topic` auto-generated channel
2. the title's leading segment equals the uploader
3. exactly one separator AND an official-video/audio marker

Anything else leaves `artist = null`. Unresolved beats confidently wrong: a
bad artist breaks lyrics, identity, artwork lookup and future history at once.
Spotify metadata is canonical and never re-derived.

## Artwork (Phase 1C.1)

`ArtworkResolver`, in order: browser-safe http(s) URI, then a YouTube
thumbnail from a **verified** video URL (a bare ID-shaped string is not
verification). Bitmap fallback is NOT implemented — see delivery notes.

## Foreground startup

`KeepaliveStatus` reports ACTIVE only after the service genuinely reaches
`startForeground()`. A background start rejected by Android 12+ is recorded,
never swallowed. The visible Activity subscribes to ObservationHub lifecycle
state, so it also retries if the NotificationListener finishes connecting only
after the Activity is already visible; no reopen/polling race remains.


## Phase 1C.1 audit corrections

- listener reconnect replaces provider/publisher without first killing an already-active FGS
- service `onDestroy()` clears keepalive ACTIVE diagnostics
- YouTube official markers are trailing closed-list suffixes only
- mixed dash types use the actual earliest separator/prefix match
- guarded exact `Artist - Track` parsing resolves the observed Radio Nova / Ezechiel Pailhes case while rejecting reaction/live-descriptor counterexamples
- debug screen exposes raw uploader, artist candidate/provenance, media URI, raw artwork URIs, bitmap availability and resolved artwork kind
- bitmap artwork upload remains deferred until a secure authenticated storage path exists
