# Listening Mirror — Android companion (Phase 2A: ambient recognition MVP)

Android device-playback detection plus optional user-started ambient music
recognition, transported as the same normalized CurrentListeningState through
the existing Supabase relay.

Phase 2A uses the AudD standard recognition API directly over HTTPS. It does
not use ShazamKit, does not upload raw microphone audio to the Listening Mirror
backend, adds no playback controls, and still does not upload Android artwork
bitmaps. Ambient audio samples go only from the phone to AudD when Ambient is
explicitly ON.

## What this does

Reads what's currently playing on the phone via Android's MediaSession
APIs (Spotify, YouTube, YouTube Music, or any other well-behaved media
app), normalizes it into the same generic `CurrentListeningState` shape
the web Mirror already understands, and displays every raw + normalized
field on one live debug screen. When Ambient is explicitly started, the app
can also sample external music through the microphone and publish an
`ambient_audd` state when no active device MediaSession already identifies it.

## Structure

```
app/src/main/java/com/listeningmirror/companion/
  model/
    RawSessionSnapshot.kt      pure snapshot of one MediaController
    CurrentListeningState.kt   the generic contract (Android side)
  logic/                       ALL pure, unit-testable, zero android.* imports
    SourceMapper.kt            package name -> source string
    PositionNormalizer.kt      sentinel/timestamp handling
    DurationNormalizer.kt      negative-means-unknown handling
    MetadataCompleteness.kt    metadataCompleteForLyrics
    ActiveSessionSelector.kt   which session is actually active
    StateNormalizer.kt         snapshot -> CurrentListeningState
  android/                     Android lifecycle / service / debug UI
    MediaNotificationListenerService.kt   permission gate only
    AndroidMediaSessionProvider.kt        event-driven MediaSession bridge
    DebugActivity.kt                      the debug screen + Ambient ON/OFF
    AmbientRecognitionService.kt         microphone FGS, recognition loop
    AmbientSettingsActivity.kt           encrypted AudD token setup
  ambient/                     AudD provider + audio/token plumbing
    AudDRecognitionClient.kt             standard multipart recognition
    AmbientAudioRecorder.kt              16 kHz mono PCM -> WAV sample
    AmbientTokenStore.kt                 encrypted no-backup API token
app/src/test/java/.../LogicTests.kt       kotlin.test unit tests
tools/VerifyRunner.kt                     standalone runner (see below)
```

## Build

```
./gradlew :app:assembleDebug
```
APK lands at `app/build/outputs/apk/debug/app-debug.apk`.

The Gradle wrapper IS included (gradlew, gradlew.bat, gradle/wrapper/),
so this command works as written -- but it still requires an Android SDK
(compileSdk 35) plus network access to Google's Maven repo on first run,
neither of which the wrapper can provide. Easiest path: open the project
in Android Studio and let it sync.

## Run the unit tests

```
./gradlew :app:testDebugUnitTest
```

`tools/VerifyRunner.kt` is a standalone duplicate of the same assertions
that runs without Gradle/JUnit/Android SDK — useful for verifying the pure
logic anywhere a JVM + kotlinc exist:

```
kotlinc app/src/main/java/com/listeningmirror/companion/model/*.kt \
        app/src/main/java/com/listeningmirror/companion/logic/*.kt \
        app/src/main/java/com/listeningmirror/companion/transport/ArtworkPolicy.kt \
        app/src/main/java/com/listeningmirror/companion/transport/PositionReanchor.kt \
        app/src/main/java/com/listeningmirror/companion/android/KeepaliveLifecycle.kt \
        tools/ManifestChecks.kt tools/VerifyRunner.kt \
        -include-runtime -d verify.jar
java -jar verify.jar
```

## Lifecycle (important)

MediaSession observation is owned by MediaNotificationListenerService,
NOT by the debug Activity. Leaving the Activity to go use Spotify or
YouTube unsubscribes only the UI -- observation keeps running, which is
the entire point. ObservationHub is the seam between the two.

## Notification Access

Android only exposes media sessions to apps with Notification Access. The
app shows whether it's granted and provides a button to open the system
settings page. Granted once, persists.

Declared permissions are deliberately narrow: INTERNET for relay transport,
FOREGROUND_SERVICE + FOREGROUND_SERVICE_SPECIAL_USE for the playback keepalive,
POST_NOTIFICATIONS for visible foreground notifications, plus RECORD_AUDIO and
FOREGROUND_SERVICE_MICROPHONE for the user-started Ambient mode. RECORD_AUDIO
is requested only when the user taps Start ambient recognition. No location.


## Ambient recognition (Phase 2A)

Ambient mode is opt-in and starts only from the visible Activity after Android
grants RECORD_AUDIO. `AmbientRecognitionService` is a separate foreground
service with `foregroundServiceType="microphone"`; it is `START_NOT_STICKY`, so
Android never silently resurrects microphone capture from the background.

Each recognition records an 8-second, 16 kHz mono PCM sample, wraps it as WAV,
and sends it directly to AudD's standard HTTPS endpoint as multipart/form-data.
The request asks for `apple_music,spotify` metadata so the normalized state can
include browser-safe artwork, duration, an external link, and AudD's timecode
position when available.

Source priority inside the Android relay is:

1. actively playing Android MediaSession
2. ambient AudD match
3. paused/stopped Android MediaSession

That means ambient never fingerprints music already exposed by Spotify/YouTube
on the phone. With no configured AudD token, the public `test` token is used in
single-shot mode (one request per START, public limit 10/day). A saved real
token enables smart continuous mode: after a match, the next sample is delayed
until near the expected end of the track instead of polling every few seconds.
The AudD token is encrypted with a separate Android Keystore key under
noBackupFilesDir and never sent to Supabase.

## Relay transport (Phase 1B-2)

`transport/` publishes the selected session's normalized state to
`public.publish_playback` on Supabase:

- immediate publish on meaningful change, coalesced by a 750ms debounce
- 20s heartbeat while a session is selected, with the position re-anchored
  to the heartbeat instant via SystemClock.elapsedRealtime()
- per-install deviceId + monotonic sequence under noBackupFilesDir, so a
  reinstall starts a fresh identity rather than restoring a stale one
- write secret encrypted with an Android Keystore AES/GCM key
- artwork transported only when http(s); content:// and bitmaps become null

Setup: open the app, tap "Relay transport settings", paste the write secret
once. Project URL and anon key are public config compiled into RelayConfig.

Canonical backend SQL: `supabase/phase1b2_transport.sql`.

## Background reliability (Phase 1C)

`PlaybackRelayForegroundService` keeps the process at foreground importance
so observation and the 20s heartbeat survive backgrounding and screen-off.
Added because a real Samsung S23 suspended the process: with YouTube
genuinely playing, Supabase `received_at` aged to 39s against a 20s
heartbeat, and the web correctly expired the state after 60s.

Its lifecycle follows the **NotificationListenerService connection**, never
playback state — a paused track or a momentarily-null session must not stop
it. `specialUse` foreground service type (not `dataSync`, which carries
Android 15 runtime time limits). A persistent low-importance notification is
a platform requirement for any foreground service.


## YouTube metadata confidence (Phase 1C.1)

`METADATA_KEY_ARTIST` on ordinary YouTube is often the UPLOADER, not the
musical artist (observed: `Rock & Roll Hall of Fame`). `YouTubeMetadataResolver`
therefore promotes it to canonical only on explicit evidence:

1. `<Artist> - Topic` auto-generated channel
2. the title's leading segment equals the uploader
3. exactly one separator AND an official-video/audio marker

Anything else leaves `artist = null`. Unresolved beats confidently wrong: a
bad artist breaks lyrics, identity, artwork lookup and future history at once.
Spotify metadata is canonical and never re-derived.

## Artwork (Phase 1C.1)

`ArtworkResolver`, in order: browser-safe http(s) URI, then a YouTube
thumbnail from a **verified** video URL (a bare ID-shaped string is not
verification). Bitmap fallback is NOT implemented — see delivery notes.

## Foreground startup

`KeepaliveStatus` reports ACTIVE only after the service genuinely reaches
`startForeground()`. A background start rejected by Android 12+ is recorded,
never swallowed. The visible Activity subscribes to ObservationHub lifecycle
state, so it also retries if the NotificationListener finishes connecting only
after the Activity is already visible; no reopen/polling race remains.


## Phase 1C.1 audit corrections

- listener reconnect replaces provider/publisher without first killing an already-active FGS
- service `onDestroy()` clears keepalive ACTIVE diagnostics
- YouTube official markers are trailing closed-list suffixes only
- mixed dash types use the actual earliest separator/prefix match
- guarded exact `Artist - Track` parsing resolves the observed Radio Nova / Ezechiel Pailhes case while rejecting reaction/live-descriptor counterexamples
- debug screen exposes raw uploader, artist candidate/provenance, media URI, raw artwork URIs, bitmap availability and resolved artwork kind
- bitmap artwork upload remains deferred until a secure authenticated storage path exists
