import com.listeningmirror.companion.logic.ActiveSessionSelector
import com.listeningmirror.companion.logic.DurationNormalizer
import com.listeningmirror.companion.logic.MetadataCompleteness
import com.listeningmirror.companion.logic.PositionNormalizer
import com.listeningmirror.companion.logic.SourceMapper
import com.listeningmirror.companion.logic.StateNormalizer
import com.listeningmirror.companion.model.RawPlaybackState
import com.listeningmirror.companion.model.RawSessionSnapshot

var pass = 0
var fail = 0
fun check(label: String, cond: Boolean) {
    if (cond) { pass++; println("✓ $label") }
    else { fail++; println("✗ $label") }
}

fun snapshot(
    packageName: String,
    state: RawPlaybackState,
    sessionId: String = "session-of-$packageName",
    artist: String? = "Artist",
    track: String? = "Track",
    album: String? = null,
    durationMsRaw: Long? = 200_000L,
    positionRaw: Long? = 1_000L,
    lastPositionUpdateTimeMs: Long? = 123_456L,
    osPriorityIndex: Int = 0,
    artUri: String? = null,
    albumArtUri: String? = null,
): RawSessionSnapshot = RawSessionSnapshot(
    sessionId = sessionId, packageName = packageName, playbackState = state, rawPlaybackStateInt = null,
    artist = artist, track = track, album = album,
    mediaId = null, mediaUri = null, artUri = artUri, albumArtUri = albumArtUri,
    hasArtBitmap = false, hasAlbumArtBitmap = false,
    durationMsRaw = durationMsRaw, positionRaw = positionRaw, lastPositionUpdateTimeMs = lastPositionUpdateTimeMs,
    playbackSpeed = 1.0f, osPriorityIndex = osPriorityIndex,
)

fun main() {
    // ---- SourceMapper ----
    check("spotify package -> spotify_android", SourceMapper.sourceFor("com.spotify.music") == "spotify_android")
    check("youtube package -> youtube_android", SourceMapper.sourceFor("com.google.android.youtube") == "youtube_android")
    check("youtube music package -> youtube_music_android", SourceMapper.sourceFor("com.google.android.apps.youtube.music") == "youtube_music_android")
    check("unknown package -> android_media", SourceMapper.sourceFor("com.example.somerandomapp") == "android_media")
    check("empty package name does not crash, falls back to android_media", SourceMapper.sourceFor("") == "android_media")

    // ---- PositionNormalizer ----
    check("valid position + valid timestamp accepted", PositionNormalizer.validAnchorOrNull(45_000L, 999L) == 45_000L)
    check("zero position is valid", PositionNormalizer.validAnchorOrNull(0L, 999L) == 0L)
    check("PLAYBACK_POSITION_UNKNOWN (-1) rejected", PositionNormalizer.validAnchorOrNull(-1L, 999L) == null)
    check("other negative position rejected", PositionNormalizer.validAnchorOrNull(-500L, 999L) == null)
    check("zero update timestamp (never set) rejected", PositionNormalizer.validAnchorOrNull(45_000L, 0L) == null)
    check("null update timestamp rejected", PositionNormalizer.validAnchorOrNull(45_000L, null) == null)
    check("null position rejected", PositionNormalizer.validAnchorOrNull(null, 999L) == null)
    check("position 0 + timestamp 0 (both edge cases at once) still rejected", PositionNormalizer.validAnchorOrNull(0L, 0L) == null)

    // ---- DurationNormalizer ----
    check("valid duration accepted", DurationNormalizer.normalize(200_000L) == 200_000L)
    check("negative duration -> null (unknown per MediaMetadata contract)", DurationNormalizer.normalize(-1L) == null)
    check("null duration -> null", DurationNormalizer.normalize(null) == null)
    check("zero duration accepted as-is", DurationNormalizer.normalize(0L) == 0L)

    // ---- MetadataCompleteness ----
    check("both artist+track present -> complete", MetadataCompleteness.isCompleteForLyrics("Mono", "Ashes in the Snow"))
    check("missing artist -> incomplete", !MetadataCompleteness.isCompleteForLyrics(null, "Track"))
    check("missing track -> incomplete", !MetadataCompleteness.isCompleteForLyrics("Artist", null))
    check("blank artist -> incomplete", !MetadataCompleteness.isCompleteForLyrics("   ", "Track"))
    check("blank track -> incomplete", !MetadataCompleteness.isCompleteForLyrics("Artist", ""))
    check("both missing -> incomplete", !MetadataCompleteness.isCompleteForLyrics(null, null))

    // ---- ActiveSessionSelector ----
    check("empty session list selects nothing", ActiveSessionSelector.select(emptyList(), null) == null)

    check("single playing session is selected",
        ActiveSessionSelector.select(listOf(snapshot("com.spotify.music", RawPlaybackState.PLAYING)), null) == "session-of-com.spotify.music")

    check("playing beats paused", ActiveSessionSelector.select(
        listOf(
            snapshot("com.spotify.music", RawPlaybackState.PAUSED, osPriorityIndex = 0),
            snapshot("com.google.android.youtube", RawPlaybackState.PLAYING, osPriorityIndex = 1),
        ), "session-of-com.spotify.music"
    ) == "session-of-com.google.android.youtube")

    check("OS priority order breaks ties between multiple playing sessions", ActiveSessionSelector.select(
        listOf(
            snapshot("com.google.android.youtube", RawPlaybackState.PLAYING, osPriorityIndex = 1),
            snapshot("com.spotify.music", RawPlaybackState.PLAYING, osPriorityIndex = 0),
        ), null
    ) == "session-of-com.spotify.music")

    check("transitional state is sticky if previously selected", ActiveSessionSelector.select(
        listOf(snapshot("com.spotify.music", RawPlaybackState.TRANSITIONAL)), "session-of-com.spotify.music"
    ) == "session-of-com.spotify.music")

    check("transitional state does NOT stick if it was not previously selected", ActiveSessionSelector.select(
        listOf(snapshot("com.google.android.youtube", RawPlaybackState.TRANSITIONAL)), "session-of-com.spotify.music"
    ) == null)

    check("does not flap to a stale paused session during previous selection's buffering (THE exact correction #3 scenario)",
        ActiveSessionSelector.select(
            listOf(
                snapshot("com.spotify.music", RawPlaybackState.TRANSITIONAL, osPriorityIndex = 0),
                snapshot("com.google.android.youtube", RawPlaybackState.PAUSED, osPriorityIndex = 1),
            ), "session-of-com.spotify.music"
        ) == "session-of-com.spotify.music")

    check("previously selected session gone entirely -> no stickiness", ActiveSessionSelector.select(
        listOf(snapshot("com.google.android.youtube", RawPlaybackState.PAUSED)), "session-of-com.spotify.music"
    ) == null)

    check("all paused with no previous selection -> nothing selected", ActiveSessionSelector.select(
        listOf(
            snapshot("com.spotify.music", RawPlaybackState.PAUSED),
            snapshot("com.google.android.youtube", RawPlaybackState.STOPPED),
        ), null
    ) == null)

    check("newly playing session overrides old transitional stickiness", ActiveSessionSelector.select(
        listOf(
            snapshot("com.spotify.music", RawPlaybackState.TRANSITIONAL, osPriorityIndex = 0),
            snapshot("com.google.android.youtube", RawPlaybackState.PLAYING, osPriorityIndex = 1),
        ), "session-of-com.spotify.music"
    ) == "session-of-com.google.android.youtube")

    // ---- StateNormalizer ----
    run {
        val snap = snapshot(
            "com.spotify.music", RawPlaybackState.PLAYING,
            artist = "Mono", track = "Ashes in the Snow", album = "Hymn to the Immortal Wind",
            durationMsRaw = 300_000L, positionRaw = 45_000L, lastPositionUpdateTimeMs = 111L,
        )
        val state = StateNormalizer.normalize(snap, "2026-01-01T00:00:00.000Z", 200_000L)
        check("normalizes a fully populated Spotify snapshot: source", state.source == "spotify_android")
        check("normalizes a fully populated Spotify snapshot: artist", state.artist == "Mono")
        check("normalizes a fully populated Spotify snapshot: primaryArtist mirrors artist", state.primaryArtist == "Mono")
        check("normalizes a fully populated Spotify snapshot: track", state.track == "Ashes in the Snow")
        check("normalizes a fully populated Spotify snapshot: durationMs", state.durationMs == 300_000L)
        check("normalizes a fully populated Spotify snapshot: positionMs advanced to capturedAt (45000 + (200000-111))", state.positionMs == 45_000L + (200_000L - 111L))
        check("normalizes a fully populated Spotify snapshot: isPlaying", state.isPlaying)
        check("normalizes a fully populated Spotify snapshot: controlsSupported is false in this phase", !state.controlsSupported)
        check("normalizes a fully populated Spotify snapshot: confidence is null (not invented)", state.confidence == null)
    }

    run {
        val snap = snapshot(
            "com.example.unknownapp", RawPlaybackState.PAUSED,
            artist = null, track = null, album = null,
            durationMsRaw = null, positionRaw = null, lastPositionUpdateTimeMs = null,
        )
        val state = StateNormalizer.normalize(snap, "2026-01-01T00:00:00.000Z", 200_000L)
        check("missing metadata never crashes normalization (artist null)", state.artist == null)
        check("missing metadata never crashes normalization (track null)", state.track == null)
        check("missing metadata never crashes normalization (durationMs null)", state.durationMs == null)
        check("missing metadata never crashes normalization (positionMs null)", state.positionMs == null)
        check("missing metadata never crashes normalization (source still android_media)", state.source == "android_media")
    }

    run {
        val snap = snapshot(
            "com.spotify.music", RawPlaybackState.PLAYING,
            positionRaw = PositionNormalizer.PLAYBACK_POSITION_UNKNOWN, lastPositionUpdateTimeMs = 999L,
        )
        val state = StateNormalizer.normalize(snap, "2026-01-01T00:00:00.000Z", 200_000L)
        check("unknown position sentinel never leaks into normalized state", state.positionMs == null)
    }

    run {
        val snap = snapshot("com.spotify.music", RawPlaybackState.PLAYING, artUri = "content://art/small", albumArtUri = "content://art/album")
        val state = StateNormalizer.normalize(snap, "2026-01-01T00:00:00.000Z", 200_000L)
        check("albumArtUri preferred over artUri when both present", state.artwork == "content://art/album")
    }

    run {
        val snap = snapshot("com.spotify.music", RawPlaybackState.PLAYING, artUri = "content://art/small", albumArtUri = null)
        val state = StateNormalizer.normalize(snap, "2026-01-01T00:00:00.000Z", 200_000L)
        check("artUri used when albumArtUri absent", state.artwork == "content://art/small")
    }


    // ---- NEW: normalized current position (correction #2) ----
    check("PLAYING advances the anchor by elapsed realtime since lastPositionUpdateTime",
        PositionNormalizer.normalizedNow(30_000L, 100_000L, RawPlaybackState.PLAYING, 105_000L) == 35_000L)
    check("PAUSED stays frozen at its anchor, ignoring elapsed time",
        PositionNormalizer.normalizedNow(30_000L, 100_000L, RawPlaybackState.PAUSED, 105_000L) == 30_000L)
    check("TRANSITIONAL (buffering) also stays frozen at its anchor",
        PositionNormalizer.normalizedNow(30_000L, 100_000L, RawPlaybackState.TRANSITIONAL, 105_000L) == 30_000L)
    check("PLAYING with zero elapsed returns the anchor unchanged",
        PositionNormalizer.normalizedNow(30_000L, 100_000L, RawPlaybackState.PLAYING, 100_000L) == 30_000L)
    check("PLAYING never runs time backwards if the update timestamp is ahead of our clock reading",
        PositionNormalizer.normalizedNow(30_000L, 100_000L, RawPlaybackState.PLAYING, 99_000L) == 30_000L)
    check("unknown sentinel stays null even while PLAYING (never advanced into a fake position)",
        PositionNormalizer.normalizedNow(-1L, 100_000L, RawPlaybackState.PLAYING, 105_000L) == null)
    check("zero update timestamp stays null even while PLAYING",
        PositionNormalizer.normalizedNow(30_000L, 0L, RawPlaybackState.PLAYING, 105_000L) == null)
    check("position 0 while PLAYING correctly advances (track just started)",
        PositionNormalizer.normalizedNow(0L, 100_000L, RawPlaybackState.PLAYING, 102_500L) == 2_500L)
    check("position 0 while PAUSED stays exactly 0 (valid, not null)",
        PositionNormalizer.normalizedNow(0L, 100_000L, RawPlaybackState.PAUSED, 105_000L) == 0L)

    // ---- NEW: same package, different sessions must not collapse ----
    run {
        val playingSession = snapshot("com.spotify.music", RawPlaybackState.PLAYING, sessionId = "spotify-session-B", osPriorityIndex = 1)
        val pausedSession = snapshot("com.spotify.music", RawPlaybackState.PAUSED, sessionId = "spotify-session-A", osPriorityIndex = 0)
        check("two sessions from the SAME package are treated as distinct; the genuinely playing one wins",
            ActiveSessionSelector.select(listOf(pausedSession, playingSession), null) == "spotify-session-B")
    }
    run {
        // Stickiness must key on the SESSION, not the package: session A of
        // Spotify buffering must not be satisfied by session B of Spotify.
        val otherSession = snapshot("com.spotify.music", RawPlaybackState.TRANSITIONAL, sessionId = "spotify-session-B")
        check("transitional stickiness does not transfer between two sessions of the same package",
            ActiveSessionSelector.select(listOf(otherSession), "spotify-session-A") == null)
    }
    run {
        val a = snapshot("com.spotify.music", RawPlaybackState.TRANSITIONAL, sessionId = "spotify-session-A", osPriorityIndex = 0)
        val b = snapshot("com.spotify.music", RawPlaybackState.PAUSED, sessionId = "spotify-session-B", osPriorityIndex = 1)
        check("correct same-package session sticks while its sibling is paused",
            ActiveSessionSelector.select(listOf(a, b), "spotify-session-A") == "spotify-session-A")
    }

    println("\n$pass passed, $fail failed")
    if (fail > 0) kotlin.system.exitProcess(1)
}
