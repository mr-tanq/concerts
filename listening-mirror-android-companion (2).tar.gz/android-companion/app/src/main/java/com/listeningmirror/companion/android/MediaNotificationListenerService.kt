package com.listeningmirror.companion.android

import android.service.notification.NotificationListenerService

/**
 * Two jobs, both structural, neither involving notification content:
 *
 *  1. Being an *enabled* NotificationListenerService is what unlocks
 *     MediaSessionManager.getActiveSessions() for a normal app (the
 *     alternative, MEDIA_CONTENT_CONTROL, is system-level).
 *
 *  2. It is the LIFECYCLE HOST for MediaSession observation. This matters
 *     more than it looks: the whole point of the companion is to observe
 *     Spotify/YouTube *while the user is in Spotify/YouTube*, which is
 *     exactly when our own Activity is backgrounded. Hosting the observer
 *     in the Activity would tear the callbacks down at the precise moment
 *     they need to be live, so the test sequence would only ever capture
 *     fresh snapshots on return -- proving nothing about continuous
 *     observation. The system binds this service and keeps it bound
 *     independently of any Activity, which is the property we need.
 *
 * It deliberately does NOT override onNotificationPosted /
 * onNotificationRemoved, and never reads notification content, text, or
 * extras. Using it as a lifecycle/permission host does not change that
 * rule. If this class ever grows notification-parsing logic, something has
 * gone off-plan.
 */
class MediaNotificationListenerService : NotificationListenerService() {

    private var provider: AndroidMediaSessionProvider? = null

    /**
     * The platform's documented signal that the listener is genuinely
     * connected and its APIs are usable -- the AOSP docs explicitly say to
     * wait for this before performing operations. Starting observation
     * from onCreate() instead would race the binding.
     */
    override fun onListenerConnected() {
        super.onListenerConnected()
        val p = AndroidMediaSessionProvider(applicationContext)
        provider = p
        ObservationHub.attachProvider(p)
        p.start { snapshot -> ObservationHub.publish(snapshot) }
    }

    override fun onListenerDisconnected() {
        // Notification Access was revoked, or the system is unbinding us.
        // Either way this is a genuine end of the continuous observation
        // session -- tear down fully, including selection stickiness.
        provider?.stop()
        provider = null
        ObservationHub.detachProvider()
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        provider?.stop()
        provider = null
        ObservationHub.detachProvider()
        super.onDestroy()
    }
}
