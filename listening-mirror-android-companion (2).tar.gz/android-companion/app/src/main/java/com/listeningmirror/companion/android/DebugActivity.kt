package com.listeningmirror.companion.android

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.listeningmirror.companion.logic.SourceMapper
import com.listeningmirror.companion.model.RawSessionSnapshot

/**
 * The entire prototype UI: a live debug screen. Built with plain views
 * rather than Compose deliberately — fewer dependencies, faster to build,
 * and this screen exists to be read, not to look good.
 *
 * Shows every field from the required debug list, keeping RAW Android
 * values next to NORMALIZED results side by side, because the point of
 * this phase is observing what Spotify and YouTube actually do on a real
 * phone — not just seeing the final answer.
 */
class DebugActivity : AppCompatActivity() {

    private lateinit var permissionSection: LinearLayout
    private lateinit var permissionText: TextView
    private lateinit var grantButton: Button
    private lateinit var selectedContainer: LinearLayout
    private lateinit var allSessionsContainer: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = ScrollView(this)
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 48)
        }
        root.addView(column)

        column.addView(heading("LISTENING MIRROR · ANDROID DEBUG"))

        permissionSection = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        permissionText = body("")
        grantButton = Button(this).apply {
            text = "Open Notification Access settings"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }
        permissionSection.addView(permissionText)
        permissionSection.addView(grantButton)
        column.addView(permissionSection)

        column.addView(heading("SELECTED SESSION"))
        selectedContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        column.addView(selectedContainer)

        column.addView(heading("ALL VISIBLE MEDIA SESSIONS"))
        allSessionsContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        column.addView(allSessionsContainer)

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        // Re-checked on every resume specifically so returning from the
        // system settings screen immediately reflects a fresh grant,
        // without needing the app to be restarted.
        refreshPermissionState()
    }

    override fun onPause() {
        super.onPause()
        // Unsubscribes the UI ONLY. MediaSession observation is owned by
        // MediaNotificationListenerService and deliberately keeps running
        // -- leaving this screen to go use Spotify or YouTube is exactly
        // the scenario the companion exists to observe, so tearing the
        // callbacks down here would defeat the entire purpose.
        ObservationHub.unsubscribe()
    }

    private fun refreshPermissionState() {
        val granted = AndroidMediaSessionProvider.hasNotificationAccess(this)
        if (granted) {
            permissionText.text = if (ObservationHub.isObserving()) {
                "Notification Access: GRANTED\nObservation: RUNNING (continues while this screen is closed)"
            } else {
                "Notification Access: GRANTED\nObservation: starting...\n\n" +
                "If this doesn't change, the system may not have bound the " +
                "listener service yet. Toggling Notification Access off and " +
                "on again forces a rebind."
            }
            grantButton.visibility = View.GONE
            ObservationHub.subscribe { snapshot ->
                runOnUiThread { render(snapshot) }
            }
        } else {
            permissionText.text =
                "Notification Access: NOT GRANTED\n\n" +
                "This app reads what's playing from Android's media sessions " +
                "(Spotify, YouTube, etc). Android only exposes that to apps " +
                "with Notification Access, which has to be granted manually " +
                "once, in system settings.\n\n" +
                "It does not read the content of your notifications."
            grantButton.visibility = View.VISIBLE
            selectedContainer.removeAllViews()
            allSessionsContainer.removeAllViews()
        }
    }

    private fun render(snapshot: ProviderSnapshot) {
        selectedContainer.removeAllViews()
        val raw = snapshot.selectedRaw
        val state = snapshot.selectedState

        if (raw == null || state == null) {
            selectedContainer.addView(body("(no active device playback)"))
        } else {
            selectedContainer.addView(row("PACKAGE", raw.packageName))
            selectedContainer.addView(row("SOURCE", state.source))
            selectedContainer.addView(row("RAW PLAYBACK STATE", "${raw.rawPlaybackStateInt} (${raw.playbackState})"))
            selectedContainer.addView(row("ARTIST", state.artist))
            selectedContainer.addView(row("TRACK", state.track))
            selectedContainer.addView(row("ALBUM", state.album))
            selectedContainer.addView(row("MEDIA ID", state.externalId))
            selectedContainer.addView(row("MEDIA URI", state.externalUrl))
            selectedContainer.addView(row("POSITION RAW", raw.positionRaw?.toString()))
            selectedContainer.addView(row("POSITION NORMALIZED", state.positionMs?.toString()))
            selectedContainer.addView(row("LAST POSITION UPDATE TIME", raw.lastPositionUpdateTimeMs?.toString()))
            // Diagnostic only — never feeds normalization in this phase.
            selectedContainer.addView(row("PLAYBACK SPEED", raw.playbackSpeed?.toString()))
            selectedContainer.addView(row("DURATION RAW", raw.durationMsRaw?.toString()))
            selectedContainer.addView(row("DURATION NORMALIZED", state.durationMs?.toString()))
            selectedContainer.addView(row("ART URI", raw.artUri))
            selectedContainer.addView(row("ALBUM ART URI", raw.albumArtUri))
            selectedContainer.addView(row("ARTWORK (normalized)", state.artwork))
            selectedContainer.addView(row("ART BITMAP AVAILABLE?", raw.hasArtBitmap.toString()))
            selectedContainer.addView(row("ALBUM ART BITMAP AVAILABLE?", raw.hasAlbumArtBitmap.toString()))
            selectedContainer.addView(row("IS PLAYING", state.isPlaying.toString()))
            selectedContainer.addView(row("METADATA COMPLETE FOR LYRICS?", snapshot.metadataCompleteForLyrics.toString()))
            selectedContainer.addView(row("CONFIDENCE", state.confidence?.toString() ?: "null (by design)"))
            selectedContainer.addView(row("CONTROLS SUPPORTED", state.controlsSupported.toString()))
            selectedContainer.addView(row("CAPTURED AT", state.capturedAt))
        }

        allSessionsContainer.removeAllViews()
        if (snapshot.allSessions.isEmpty()) {
            allSessionsContainer.addView(body("(no media sessions visible)"))
        } else {
            snapshot.allSessions.forEach { session ->
                allSessionsContainer.addView(sessionBlock(session, session.sessionId == snapshot.selectedSessionId))
            }
        }
    }

    private fun sessionBlock(session: RawSessionSnapshot, isSelected: Boolean): View {
        val block = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 20, 0, 20)
        }
        block.addView(body(if (isSelected) "▸ SELECTED" else "  not selected"))
        block.addView(row("  package", session.packageName))
        block.addView(row("  source", SourceMapper.sourceFor(session.packageName)))
        block.addView(row("  raw state", "${session.rawPlaybackStateInt} (${session.playbackState})"))
        block.addView(row("  os priority index", session.osPriorityIndex.toString()))
        block.addView(row("  title", session.track))
        block.addView(row("  artist", session.artist))
        return block
    }

    private fun heading(text: String) = TextView(this).apply {
        this.text = text
        textSize = 13f
        setPadding(0, 44, 0, 16)
        typeface = android.graphics.Typeface.MONOSPACE
    }

    private fun body(text: String) = TextView(this).apply {
        this.text = text
        textSize = 12f
        typeface = android.graphics.Typeface.MONOSPACE
    }

    private fun row(label: String, value: String?) = TextView(this).apply {
        text = "$label: ${value ?: "null"}"
        textSize = 12f
        setPadding(0, 4, 0, 4)
        typeface = android.graphics.Typeface.MONOSPACE
    }
}
