package com.listeningmirror.companion.transport

import android.content.Context
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import com.listeningmirror.companion.android.ProviderSnapshot
import com.listeningmirror.companion.model.CurrentListeningState
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** Latest publish outcome, for the settings/debug screen. */
data class PublishStatus(
    val lastAttemptAt: String?,
    val lastSuccessAt: String?,
    val lastResult: String?,
    val consecutiveFailures: Int,
    val hasSecret: Boolean,
    /** Application-level rejection from the RPC, e.g. invalid_secret,
     *  stale_sequence, active_other_device. Null when the last publish
     *  was genuinely accepted. */
    val lastRejectionReason: String?,
)

/**
 * Owns everything between the observation layer and the relay: debounce,
 * sequence allocation, heartbeat with position re-anchoring, and retry.
 *
 * Runs on its own HandlerThread -- MediaController callbacks arrive on the
 * main thread and must never block on network I/O.
 */
class RelayPublisher(context: Context) {

    private val appContext = context.applicationContext
    private val identity = DeviceIdentity(appContext)
    private val secrets = DeviceSecretStore(appContext)

    private val thread = HandlerThread("relay-publisher").apply { start() }
    private val handler = Handler(thread.looper)

    private val isoFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    // Last state received from observation, plus the MONOTONIC instant it
    // arrived. The pair is what makes heartbeat re-anchoring correct.
    private var lastState: CurrentListeningState? = null
    private var transportAnchorElapsedMs: Long = 0L

    private var retryIndex = 0
    private var consecutiveFailures = 0
    private var lastAttemptAt: String? = null
    private var lastSuccessAt: String? = null
    private var lastResult: String? = null
    private var lastRejectionReason: String? = null

    @Volatile private var running = false

    private val debounceRunnable = Runnable { publishNow(reanchorForHeartbeat = false) }
    private val heartbeatRunnable = object : Runnable {
        override fun run() {
            if (!running) return
            publishNow(reanchorForHeartbeat = true)
            handler.postDelayed(this, RelayConfig.HEARTBEAT_MS)
        }
    }

    fun start() {
        running = true
        handler.removeCallbacks(heartbeatRunnable)
        handler.postDelayed(heartbeatRunnable, RelayConfig.HEARTBEAT_MS)
    }

    /**
     * Terminal. The publisher is created per listener-connection, so the
     * HandlerThread MUST be torn down here -- otherwise every
     * disconnect/reconnect cycle (revoking and re-granting Notification
     * Access, or the system rebinding the service) would leak one live
     * thread per publisher instance for the process lifetime.
     */
    fun stop() {
        running = false
        handler.removeCallbacksAndMessages(null)
        lastState = null
        // Best-effort explicit "nothing playing" so the web clears in ~1s
        // rather than waiting out the full 60s TTL on a clean shutdown --
        // then quit, queued AFTER it so the publish actually goes out.
        handler.post {
            publishNow(reanchorForHeartbeat = false)
            thread.quitSafely()
        }
    }

    fun saveSecret(secret: String) = secrets.save(secret.trim())
    fun clearSecret() = secrets.clear()
    fun status(): PublishStatus = PublishStatus(
        lastAttemptAt, lastSuccessAt, lastResult, consecutiveFailures,
        secrets.hasSecret(), lastRejectionReason
    )

    /** Second call from the service, alongside ObservationHub.publish(). */
    fun onSnapshot(snapshot: ProviderSnapshot) {
        handler.post {
            lastState = snapshot.selectedState
            transportAnchorElapsedMs = SystemClock.elapsedRealtime()
            // Coalesce the 3-4 callbacks Android fires around one track
            // change into a single publish.
            handler.removeCallbacks(debounceRunnable)
            handler.postDelayed(debounceRunnable, RelayConfig.DEBOUNCE_MS)
        }
    }

    private fun publishNow(reanchorForHeartbeat: Boolean) {
        val secret = secrets.load() ?: run {
            lastResult = "no secret configured"
            return
        }
        val capturedAt = isoFormat.format(Date())

        val stateToSend: CurrentListeningState? = lastState?.let { state ->
            if (reanchorForHeartbeat) {
                val delta = SystemClock.elapsedRealtime() - transportAnchorElapsedMs
                PositionReanchor.reanchor(state, delta, capturedAt)
            } else state
        }

        val sequence = try {
            identity.nextSequence()
        } catch (e: Exception) {
            // Durable sequence allocation failed -- skip this publish rather
            // than sending a sequence that isn't recorded on disk.
            lastResult = "sequence persistence failed: ${e.message}".take(160)
            consecutiveFailures++
            return
        }

        val envelope = JSONObject().apply {
            put("p_secret", secret)
            put("p_schema_version", RelayConfig.SCHEMA_VERSION)
            put("p_device_id", identity.deviceId)
            put("p_sequence", sequence)
            put("p_state", stateToSend?.let { StateJson.toJson(it) } ?: JSONObject.NULL)
            put("p_captured_at", stateToSend?.capturedAt ?: capturedAt)
        }

        lastAttemptAt = capturedAt
        val ok = post(envelope)
        if (ok) {
            // Only a genuinely ACCEPTED application-level write counts.
            lastSuccessAt = capturedAt
            lastRejectionReason = null
            consecutiveFailures = 0
            retryIndex = 0
        } else {
            consecutiveFailures++
            // Retry with backoff. Only ever the LATEST state is resent --
            // no queue, no backlog; a retry always carries current truth.
            if (retryIndex < RelayConfig.RETRY_BACKOFF_MS.size) {
                val delay = RelayConfig.RETRY_BACKOFF_MS[retryIndex]
                retryIndex++
                handler.postDelayed({ publishNow(reanchorForHeartbeat = true) }, delay)
            } else {
                retryIndex = 0 // fall back to normal heartbeat cadence
            }
        }
    }

    private fun post(body: JSONObject): Boolean {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(RelayConfig.PROJECT_URL + RelayConfig.PUBLISH_RPC).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 10_000
                readTimeout = 10_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("apikey", RelayConfig.ANON_KEY)
                setRequestProperty("Authorization", "Bearer " + RelayConfig.ANON_KEY)
            }
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
            val code = conn.responseCode
            if (code in 200..299) {
                val text = conn.inputStream.bufferedReader().use { it.readText() }
                // A 2xx only means the round trip worked. The RPC still
                // reports application-level rejection in its body, and
                // reporting "invalid_secret" as a successful publish would
                // hide the single most likely setup mistake behind a green
                // status. Parse it and surface the reason distinctly.
                val accepted = try {
                    JSONObject(text).optBoolean("accepted", false)
                } catch (e: Exception) { false }
                val reason = try {
                    JSONObject(text).optString("reason", "")
                } catch (e: Exception) { "" }

                lastRejectionReason = if (accepted) null else reason.ifEmpty { "rejected" }
                lastResult = if (accepted) "accepted ($reason)" else "REJECTED: ${reason.ifEmpty { "unknown" }}"
                accepted
            } else {
                lastRejectionReason = null
                lastResult = "HTTP $code"
                false
            }
        } catch (e: Exception) {
            lastResult = e.message?.take(160) ?: "network error"
            false
        } finally {
            conn?.disconnect()
        }
    }
}
