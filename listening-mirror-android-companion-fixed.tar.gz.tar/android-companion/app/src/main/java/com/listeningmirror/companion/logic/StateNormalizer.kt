package com.listeningmirror.companion.logic

import com.listeningmirror.companion.model.CurrentListeningState
import com.listeningmirror.companion.model.RawPlaybackState
import com.listeningmirror.companion.model.RawSessionSnapshot

/**
 * Turns the SELECTED RawSessionSnapshot into a CurrentListeningState. Pure
 * function of its inputs -- everything beyond simple field copying is
 * delegated to the other logic/ objects, so this stays a thin wiring layer
 * rather than re-implementing any of their rules.
 */
object StateNormalizer {
    /**
     * @param elapsedRealtimeNowMs SystemClock.elapsedRealtime() captured at
     *        the SAME moment as capturedAtIso. Both describe one instant --
     *        that's precisely what makes the resulting positionMs mean
     *        "position as of capturedAt" rather than "position as of
     *        whenever Android last happened to update its anchor".
     */
    fun normalize(
        snapshot: RawSessionSnapshot,
        capturedAtIso: String,
        elapsedRealtimeNowMs: Long,
    ): CurrentListeningState {
        val artwork = snapshot.albumArtUri ?: snapshot.artUri
        val source = SourceMapper.sourceFor(snapshot.packageName)
        return CurrentListeningState(
            source = source,
            artist = snapshot.artist,
            primaryArtist = snapshot.artist,
            // YouTube-only, conservative cleanup. snapshot.track keeps the
            // untouched raw title for the debug screen; only the
            // normalized contract field is cleaned. Spotify passes
            // through TitleNormalizer unchanged by design.
            track = TitleNormalizer.normalizeTrack(source, snapshot.track, snapshot.artist),
            album = snapshot.album,
            artwork = artwork,
            isPlaying = snapshot.playbackState == RawPlaybackState.PLAYING,
            durationMs = DurationNormalizer.normalize(snapshot.durationMsRaw),
            positionMs = PositionNormalizer.normalizedNow(
                positionRaw = snapshot.positionRaw,
                lastPositionUpdateTimeMs = snapshot.lastPositionUpdateTimeMs,
                state = snapshot.playbackState,
                elapsedRealtimeNowMs = elapsedRealtimeNowMs,
            ),
            externalId = snapshot.mediaId,
            externalUrl = snapshot.mediaUri,
            confidence = null,
            capturedAt = capturedAtIso,
            controlsSupported = false,
        )
    }
}
