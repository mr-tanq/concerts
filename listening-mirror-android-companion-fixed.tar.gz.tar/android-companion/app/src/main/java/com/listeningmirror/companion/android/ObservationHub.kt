package com.listeningmirror.companion.android

/**
 * The seam between the LONG-LIVED observation (owned by
 * MediaNotificationListenerService, alive as long as the system keeps the
 * listener bound) and the SHORT-LIVED debug UI (the Activity, alive only
 * while on screen).
 *
 * This exists specifically so that leaving the Activity to go use Spotify
 * or YouTube -- which is the entire scenario the companion needs to
 * observe -- unsubscribes only the UI, never the MediaSession callbacks
 * themselves. The Activity subscribes on resume and unsubscribes on pause;
 * observation carries on regardless.
 *
 * Deliberately a plain object rather than a bound-service/Binder setup:
 * both sides live in the same process, and a Binder round-trip would add
 * real complexity for no behavioral gain in a single-process debug tool.
 *
 * `latest` is retained so a returning Activity can render immediately
 * instead of showing an empty screen until the next Android event happens
 * to fire -- with an event-driven design and no polling, that next event
 * could be a long time coming if playback is simply steady.
 */
object ObservationHub {

    @Volatile
    private var latest: ProviderSnapshot? = null

    @Volatile
    private var uiObserver: ((ProviderSnapshot) -> Unit)? = null

    @Volatile
    private var provider: AndroidMediaSessionProvider? = null

    /** Called by the service when observation starts. */
    fun attachProvider(provider: AndroidMediaSessionProvider) {
        this.provider = provider
    }

    /**
     * Called by the service when observation genuinely ends (listener
     * disconnected/destroyed). Clears `latest` too: a stale snapshot from
     * a dead observation session would be actively misleading on screen,
     * showing a track as current when nothing is being observed anymore.
     */
    fun detachProvider() {
        this.provider = null
        this.latest = null
        uiObserver?.invoke(
            ProviderSnapshot(
                selectedState = null,
                selectedRaw = null,
                metadataCompleteForLyrics = false,
                allSessions = emptyList(),
                selectedSessionId = null,
            )
        )
    }

    /** Called by the provider on every real Android event. */
    fun publish(snapshot: ProviderSnapshot) {
        latest = snapshot
        uiObserver?.invoke(snapshot)
    }

    /** True when the service is actively observing right now. */
    fun isObserving(): Boolean = provider != null

    /**
     * Subscribe the UI. Immediately replays the most recent snapshot if
     * one exists, so a returning Activity paints straight away.
     */
    fun subscribe(observer: (ProviderSnapshot) -> Unit) {
        uiObserver = observer
        latest?.let(observer)
    }

    /** Unsubscribe the UI only -- observation itself is unaffected. */
    fun unsubscribe() {
        uiObserver = null
    }
}
