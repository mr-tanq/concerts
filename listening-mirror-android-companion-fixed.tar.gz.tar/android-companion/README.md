# Listening Mirror — Android companion (Phase 1B-2: Device Playback + relay transport)

Android device-playback detection, plus transport of the normalized
CurrentListeningState to the web app via a Supabase relay.

Still NO ShazamKit, no microphone, no ambient recognition, no playback
controls, no artwork bitmap upload, and no changes to mirror.js (the web
Android provider is proven on a separate debug page; Spotify-vs-Android
arbitration is Phase 1C).

## What this does

Reads what's currently playing on the phone via Android's MediaSession
APIs (Spotify, YouTube, YouTube Music, or any other well-behaved media
app), normalizes it into the same generic `CurrentListeningState` shape
the web Mirror already understands, and displays every raw + normalized
field on one live debug screen.

## Structure

```
app/src/main/java/com/listeningmirror/companion/
  model/
    RawSessionSnapshot.kt      pure snapshot of one MediaController
    CurrentListeningState.kt   the generic contract (Android side)
  logic/                       ALL pure, unit-testable, zero android.* imports
    SourceMapper.kt            package name -> source string
    PositionNormalizer.kt      sentinel/timestamp handling
    DurationNormalizer.kt      negative-means-unknown handling
    MetadataCompleteness.kt    metadataCompleteForLyrics
    ActiveSessionSelector.kt   which session is actually active
    StateNormalizer.kt         snapshot -> CurrentListeningState
  android/                     the only files that touch android.*
    MediaNotificationListenerService.kt   permission gate only
    AndroidMediaSessionProvider.kt        event-driven MediaSession bridge
    DebugActivity.kt                      the debug screen
app/src/test/java/.../LogicTests.kt       kotlin.test unit tests
tools/VerifyRunner.kt                     standalone runner (see below)
```

## Build

```
./gradlew :app:assembleDebug
```
APK lands at `app/build/outputs/apk/debug/app-debug.apk`.

The Gradle wrapper IS included (gradlew, gradlew.bat, gradle/wrapper/),
so this command works as written -- but it still requires an Android SDK
(compileSdk 35) plus network access to Google's Maven repo on first run,
neither of which the wrapper can provide. Easiest path: open the project
in Android Studio and let it sync.

## Run the unit tests

```
./gradlew :app:testDebugUnitTest
```

`tools/VerifyRunner.kt` is a standalone duplicate of the same assertions
that runs without Gradle/JUnit/Android SDK — useful for verifying the pure
logic anywhere a JVM + kotlinc exist:

```
kotlinc app/src/main/java/com/listeningmirror/companion/model/*.kt \
        app/src/main/java/com/listeningmirror/companion/logic/*.kt \
        tools/VerifyRunner.kt -include-runtime -d verify.jar
java -jar verify.jar
```

## Lifecycle (important)

MediaSession observation is owned by MediaNotificationListenerService,
NOT by the debug Activity. Leaving the Activity to go use Spotify or
YouTube unsubscribes only the UI -- observation keeps running, which is
the entire point. ObservationHub is the seam between the two.

## Notification Access

Android only exposes media sessions to apps with Notification Access. The
app shows whether it's granted and provides a button to open the system
settings page. Granted once, persists.

The only permission is INTERNET, used solely to publish state to the relay.
No microphone. No location.

## Relay transport (Phase 1B-2)

`transport/` publishes the selected session's normalized state to
`public.publish_playback` on Supabase:

- immediate publish on meaningful change, coalesced by a 750ms debounce
- 20s heartbeat while a session is selected, with the position re-anchored
  to the heartbeat instant via SystemClock.elapsedRealtime()
- per-install deviceId + monotonic sequence under noBackupFilesDir, so a
  reinstall starts a fresh identity rather than restoring a stale one
- write secret encrypted with an Android Keystore AES/GCM key
- artwork transported only when http(s); content:// and bitmaps become null

Setup: open the app, tap "Relay transport settings", paste the write secret
once. Project URL and anon key are public config compiled into RelayConfig.

Canonical backend SQL: `supabase/phase1b2_transport.sql`.
